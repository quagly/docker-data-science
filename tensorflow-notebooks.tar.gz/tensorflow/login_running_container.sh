#!/bin/bash

set -euo pipefail

docker exec -u 501 -it tensorflow bash -l
